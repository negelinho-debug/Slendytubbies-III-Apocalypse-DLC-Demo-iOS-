#!/usr/bin/env python3
"""Run an installed AssetRipper CLI; cannot run without an external binary."""
import argparse
from pathlib import Path
import subprocess
import shutil

def main():
    p=argparse.ArgumentParser()
    p.add_argument("--binary", required=True, help="Path to AssetRipper CLI executable (nowl-it/AssetRipperCLI)")
    p.add_argument("--data", default="staged/The Apocalypse_Data")
    p.add_argument("--output", default="recovered_project")
    a=p.parse_args()
    bin_path=shutil.which(a.binary) or (str(Path(a.binary).resolve()) if Path(a.binary).exists() else None)
    inp=Path(a.data).resolve(); out=Path(a.output).resolve()
    if not bin_path:
        raise SystemExit("AssetRipper CLI not found. Install it first; see README_RU.md")
    if not inp.is_dir() or not (inp/'globalgamemanagers').is_file() or not (inp/'level2').is_file():
        raise SystemExit("Missing staged ORIGINAL Windows _Data: " + str(inp))
    out.mkdir(parents=True,exist_ok=True)
    cmd=[bin_path,'--cli','--input',str(inp),'--output',str(out),'--mode','unity',
         '--script-content-level','Level0']
    print('RUNNING:', ' '.join(cmd),flush=True)
    ret=subprocess.run(cmd, check=False)
    if ret.returncode:
        print('AssetRipper failed; study its logs and missing dependencies.')
        return ret.returncode
    found=list(out.rglob('Assets'))
    if not found:
        print('Export process exited normally, but no Assets folder was found. Inspect output manually.')
        return 3
    print('EXPORTED candidate Assets folders:')
    for path in found[:15]: print(path)
    print('IMPORTANT: an exported project does not mean that it runs or builds for iOS.')
    return 0
if __name__ == '__main__': raise SystemExit(main())
