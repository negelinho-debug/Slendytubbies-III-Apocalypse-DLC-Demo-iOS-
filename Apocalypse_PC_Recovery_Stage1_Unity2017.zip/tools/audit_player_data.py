#!/usr/bin/env python3
"""Audit and optionally extract an ORIGINAL Unity 2017 Windows _Data archive.
Requires only Python 3.9+. NEVER generates a Unity project or an IPA.
"""
from __future__ import annotations
import argparse
import csv
import hashlib
import io
import json
import shutil
import struct
import zipfile
from pathlib import Path

VERSION = "2017.1.1f1"
DATA_FILES = [
    "globalgamemanagers", "globalgamemanagers.assets", "level0", "level1", "level2", "level3",
    "sharedassets0.assets", "sharedassets0.assets.resS", "sharedassets0.resource",
    "sharedassets2.assets", "sharedassets2.assets.resS", "sharedassets2.resource",
    "resources.assets", "resources.assets.resS", "resources.resource",
]
DLL_FILES = [
    "Assembly-CSharp.dll", "Assembly-UnityScript-firstpass.dll", "Boo.Lang.dll",
    "mscorlib.dll", "System.dll", "System.Core.dll", "UnityEngine.dll",
    "UnityEngine.UI.dll", "UnityEngine.Networking.dll", "VacuumShaders.TerrainToMesh.dll",
]
EXPECTED = {"The Apocalypse_Data/"+x for x in DATA_FILES} | {
    "The Apocalypse_Data/Managed/"+x for x in DLL_FILES
}
SERIALIZED = {"globalgamemanagers", "globalgamemanagers.assets", "level0", "level1", "level2", "level3",
    "sharedassets0.assets", "sharedassets2.assets", "resources.assets"}

def parse_unity_header(data: bytes, file_size: int) -> dict:
    if len(data) < 36:
        return {"valid": False, "reason": "file too short"}
    metadata, recorded_length, fmt, start = struct.unpack_from(">4I", data)
    version = data[20:].split(b"\0", 1)[0].decode("ascii", "replace")
    valid = recorded_length == file_size and fmt == 17 and version == VERSION and 20 < metadata <= start < file_size
    return {
        "valid": valid, "metadata_bytes": metadata, "file_size_in_header": recorded_length,
        "format_version": fmt, "data_offset": start, "unity_version": version,
    }

def audit(archive_path: Path, report_dir: Path, extract_dir: Path | None = None) -> dict:
    report_dir.mkdir(parents=True, exist_ok=True)
    rows, missing, invalid = [], [], []
    with zipfile.ZipFile(archive_path) as z:
        present = {n for n in z.namelist() if not n.endswith("/")}
        missing = sorted(EXPECTED - present)
        for name in sorted(EXPECTED & present):
            entry = z.getinfo(name)
            h = hashlib.sha256()
            first_bytes = bytearray()
            target = (extract_dir / name) if extract_dir else None
            if target:
                target.parent.mkdir(parents=True, exist_ok=True)
            src = z.open(entry)
            dst = target.open("wb") if target else None
            try:
                while True:
                    chunk = src.read(4 * 1024 * 1024)
                    if not chunk:
                        break
                    h.update(chunk)
                    if len(first_bytes) < 128:
                        first_bytes.extend(chunk[:128-len(first_bytes)])
                    if dst:
                        dst.write(chunk)
            finally:
                src.close()
                if dst:
                    dst.close()
            row = {"path": name, "bytes": entry.file_size, "sha256": h.hexdigest()}
            short = name.removeprefix("The Apocalypse_Data/")
            if short in SERIALIZED:
                row["unity_header"] = parse_unity_header(bytes(first_bytes), entry.file_size)
                if not row["unity_header"]["valid"]:
                    invalid.append(name)
            rows.append(row)
    status = {
        "source_archive": archive_path.name,
        "unity_version_expected": VERSION,
        "found_expected_file_count": len(rows),
        "expected_file_count": len(EXPECTED),
        "missing_files": missing,
        "invalid_unity_serialized_files": invalid,
        "optional_or_not_supplied_dependency": "Managed/Assembly-CSharp-firstpass.dll (referenced by main game assembly; check original folder)",
        "audit_ok": not missing and not invalid,
        "unity_project_restored": False,
        "ipa_created": False,
        "files": rows,
    }
    (report_dir / "audit.json").write_text(json.dumps(status, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    with (report_dir / "files.csv").open("w", encoding="utf-8", newline="") as f:
        w=csv.DictWriter(f, fieldnames=["path", "bytes", "sha256", "unity_version", "unity_header_valid"])
        w.writeheader()
        for r in rows:
            w.writerow({"path":r["path"], "bytes":r["bytes"], "sha256":r["sha256"],
               "unity_version":r.get("unity_header",{}).get("unity_version",""),
               "unity_header_valid":r.get("unity_header",{}).get("valid", "")})
    lines = [
        "SLENDYTUBBIES III APOCALYPSE DLC - WINDOWS PLAYER DATA AUDIT",
        "Source: " + archive_path.name,
        "Unity: " + VERSION,
        f"Expected files found: {len(rows)}/{len(EXPECTED)}",
        "All serialized Unity headers valid: " + ("YES" if not invalid else "NO"),
        "Missing: " + (", ".join(missing) or "none of required listed files"),
        "Possible missing external DLL: Assembly-CSharp-firstpass.dll",
        "Status: binary assets audited; editable Unity project NOT restored; IPA NOT created.",
        "Next: run AssetRipper on complete The Apocalypse_Data folder; inspect Unity project import errors.",
    ]
    (report_dir / "STATUS_RU.txt").write_text("\n".join(lines)+"\n", encoding="utf-8")
    return status

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--archive", required=True, type=Path, help="Apocalypse_Unity_Player_Data.zip")
    p.add_argument("--report-dir", default="reports", type=Path)
    p.add_argument("--extract-dir", type=Path, help="Optional directory to stage the Unity binaries")
    args=p.parse_args()
    result=audit(args.archive, args.report_dir, args.extract_dir)
    print("Files:",result["found_expected_file_count"],"/",result["expected_file_count"])
    print("Audit OK:",result["audit_ok"])
    print("Unity project restored: NO; IPA ready: NO")
    print("Report:", args.report_dir / "STATUS_RU.txt")
    return 0 if result["audit_ok"] else 2
if __name__ == "__main__":
    raise SystemExit(main())
