import sys, struct, tempfile, unittest, zipfile
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]/'tools'))
from audit_player_data import parse_unity_header, audit

class PlayerDataTests(unittest.TestCase):
    def test_header_parsing(self):
        n=128
        data=struct.pack('>5I',40,n,17,64,0) + b'2017.1.1f1\0' + bytes(128)
        self.assertTrue(parse_unity_header(data,n)['valid'])
        self.assertFalse(parse_unity_header(data,127)['valid'])
    def test_missing_detection(self):
        with tempfile.TemporaryDirectory() as t:
            z=Path(t)/'partial.zip'
            with zipfile.ZipFile(z,'w') as f:f.writestr('The Apocalypse_Data/Managed/a.dll',b'abc')
            report=audit(z,Path(t)/'report')
            self.assertFalse(report['audit_ok'])
            self.assertIn('The Apocalypse_Data/level2',report['missing_files'])

if __name__=='__main__':unittest.main()
