# Slendytubbies III: Apocalypse DLC — PC → Unity, восстановление (этап 1)

**Это не IPA и не уже восстановленная игра.** Набор для проверки оригинальных файлов Windows-версии Unity 2017.1.1f1 и подготовки их к AssetRipper. Не содержит игровых ресурсов правообладателя; можно добавить скрипты в публичный GitHub.

## Что установлено по фактическим файлам

- Windows-игра: Unity 2017.1.1f1, сериализованные сцены level0, level1, level2, level3.
- Есть `Managed/Assembly-CSharp.dll`, `resources.assets`, `sharedassets0.assets`, `sharedassets2.assets` и сопутствующие .resS/.resource.
- Главная DLL ссылается на `Assembly-CSharp-firstpass.dll`; файл не был получен среди 25 файлов и может потребоваться.
- Нет подтверждённого **открываемого рабочего Unity-проекта**, скрипты не проверялись на компиляцию в Unity, сцены пока не запускались.
- На iOS Unity 2017 использует IL2CPP. Одного Mono-DLL или Windows Unity assets недостаточно, нужен работающий проект, iOS-экспорт и подпись.

## Быстрый путь с подготовленным архивом

Нужно иметь `Apocalypse_Unity_Player_Data.zip` с **собственными файлами оригинальной ПК-версии** (подготовлен в этой беседе). Не выкладывай игровые файлы в публичный репозиторий без разрешения правообладателя.

1. Проверка (Python 3.9+, на ПК или в рабочей среде с Python):

   ```sh
   python tools/audit_player_data.py --archive Apocalypse_Unity_Player_Data.zip --report-dir reports
   ```

   Читай `reports/STATUS_RU.txt`. Это **проверка архива**, не экспорт сцены.

2. Распаковать в правильное дерево с повторной проверкой:

   ```sh
   python tools/audit_player_data.py --archive Apocalypse_Unity_Player_Data.zip --report-dir reports --extract-dir staged
   ```

   Получится `staged/The Apocalypse_Data/`.

3. Установить **AssetRipper CLI**, например его CLI-ветку с документированной командной строкой:
   https://github.com/nowl-it/AssetRipperCLI

   Перед запуском проверяй наличие `--cli --input --output --mode` через `AssetRipper --help`.

4. Попытка создания редактируемого Unity-проекта:

   ```sh
   python tools/run_assetripper.py --binary AssetRipper --data 'staged/The Apocalypse_Data' --output recovered_project
   ```

   Если AssetRipper не установлен, эта команда честно сообщит об отсутствии инструмента. Экспорт **может быть частичным**: C#/UnityScript, плагины, сцены и материалы нужно восстанавливать/исправлять.

5. Сначала открой экспортированный проект в подходящем редакторе Unity, совместимом с 2017.1.1f1, проверь импорт, ошибки компиляции, Missing Scripts и запуск `DEMOLEVEL`. Скрипт `Editor/ApocalypseRecoveryAudit.cs` можно скопировать в `Assets/Editor/` проекта и запустить меню **Apocalypse → Inspect Recovered Scenes**. Он создаст отчёт, но ничего не исправляет.

6. Только после успешного запуска можно подключать управление под iPhone и пытаться экспортировать iOS (Unity + macOS/Xcode/подпись). `.ipa` появится только после реальной iOS-сборки.

## Что загружать в GitHub

Этот ZIP содержит безопасные **инструменты, отчёт и инструкции**, а не оригинальные модели/звуки.

- При желании распакуй папки `tools/`, `tests/`, `docs/` в `recovery/` репозитория.
- Файл `.github/workflows/check-recovery-tools.yml` можно добавить по такому же пути — он запускает **только тест скрипта**, а не сборку IPA.
- Большой `Apocalypse_Unity_Player_Data.zip` не добавляй в публичный репозиторий без прав на распространение.
- Старые Actions, ожидающие удалённый Android APK, **не** выполняют восстановление ПК-игры.

## Мобильное управление — позже

По предоставленным скриншотам: верхние HINT / INV / SET / II; справа NV / CROUCH / RUN / USE; обзор свайпом справа, джойстик слева, ночное видение камеры, настраиваемый инвентарь Campaign Extra, возможное переключение первого/третьего лица. Это **задание на будущее**; в этом наборе сенсорное управление специально не встраивается.

## Реальный статус

Данный ZIP проверяет исходные файлы и готовит вход для AssetRipper; **не гарантирует**, что AssetRipper создаст рабочую сцену. Скрипты не заменяют восстановление исходного Unity-проекта и не создают IPA.
