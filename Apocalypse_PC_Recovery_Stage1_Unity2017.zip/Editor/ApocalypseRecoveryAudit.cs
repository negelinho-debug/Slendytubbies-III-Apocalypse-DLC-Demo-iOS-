// Copy to Assets/Editor after importing AssetRipper output into Unity.
// UNITY 2017.1 compatibility: Editor menu and batchmode entry point.
// This script does not repair missing MonoScripts or build an IPA.
using System;
using System.IO;
using System.Text;
using UnityEngine;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine.SceneManagement;

public static class ApocalypseRecoveryAudit
{
    [MenuItem("Apocalypse/Inspect Recovered Scenes")]
    public static void Run()
    {
        var sb = new StringBuilder();
        sb.AppendLine("Apocalypse DLC recovered-project scene audit");
        sb.AppendLine("UNITY: " + Application.unityVersion);
        string[] guids = AssetDatabase.FindAssets("t:Scene");
        sb.AppendLine("Scene assets found: " + guids.Length);
        int totalMissingComponents = 0;
        int totalObjects = 0;
        int failedScenes = 0;
        foreach (string id in guids)
        {
            var path = AssetDatabase.GUIDToAssetPath(id);
            try
            {
                var scene = EditorSceneManager.OpenScene(path, OpenSceneMode.Single);
                int missing = 0;
                int objects = 0;
                foreach (GameObject root in scene.GetRootGameObjects())
                {
                    var trs = root.GetComponentsInChildren<Transform>(true);
                    objects += trs.Length;
                    var components = root.GetComponentsInChildren<Component>(true);
                    foreach (Component c in components)
                        if (c == null) missing++;
                }
                totalObjects += objects;
                totalMissingComponents += missing;
                sb.AppendLine(path + " | GameObjects: " + objects + " | Missing Components: " + missing);
            }
            catch (Exception ex)
            {
                failedScenes++;
                sb.AppendLine("ERROR " + path + " | " + ex.Message);
            }
        }
        sb.AppendLine("TOTAL GameObjects: " + totalObjects);
        sb.AppendLine("TOTAL Missing Components: " + totalMissingComponents);
        sb.AppendLine("FAILED Scene imports: " + failedScenes);
        sb.AppendLine("NOTE: scene objects present != original gameplay restored.");
        string report = Path.Combine(Directory.GetCurrentDirectory(), "ApocalypseRecovery_SceneAudit.txt");
        File.WriteAllText(report, sb.ToString());
        Debug.Log("Scene audit saved: " + report + "\n" + sb.ToString());
    }
}
