#!/usr/bin/env python3
"""Read-only inspection of Unity 2017 IL2CPP APK metadata and serialized script links.
Does not reconstruct source code or build an iOS application.
"""
import csv
import os
import glob
import struct
import zipfile
import collections
import traceback
import sys

OUT='output'
os.makedirs(OUT, exist_ok=True)

APK = glob.glob('input/*.apk')
if len(APK) != 1:
    raise SystemExit(f'Expected exactly one APK, found {len(APK)}')

with zipfile.ZipFile(APK[0]) as z:
    meta_name = 'assets/bin/Data/Managed/Metadata/global-metadata.dat'
    bundle_name = 'assets/bin/Data/data.unity3d'
    metadata = z.read(meta_name)
    if '--metadata-only' not in sys.argv:
        with z.open(bundle_name) as source, open('game.unity3d','wb') as dest:
            import shutil
            shutil.copyfileobj(source,dest)

if len(metadata)<272:
    raise SystemExit('Metadata file is too short')
magic, version = struct.unpack_from('<II', metadata,0)
if magic != 0xFAB11BAF or version != 24:
    raise SystemExit(f'Unsupported IL2CPP metadata (magic={magic:#x}, version={version})')

# Version 24: offset-count pairs are stored after the 8-byte header.
def section(index):
    o,size = struct.unpack_from('<II',metadata,8+index*8)
    if o < 0 or size < 0 or o + size > len(metadata):
        raise ValueError(f'Corrupt section {index}')
    return o,size

string_o,string_len = section(2)
types_o,types_len=section(19)
methods_o,methods_len=section(5)
if types_len%104 or methods_len%56:
    raise SystemExit('Unexpected metadata layout: cannot safely parse class/method records')

def string_at(idx):
    if idx<0 or idx>=string_len:
        return ''
    start=string_o+idx
    end=metadata.find(b'\0',start,string_o+string_len)
    if end<0:
        return ''
    return metadata[start:end].decode('utf-8','replace')

classes=[]
for i in range(types_len//104):
    x=struct.unpack_from('<26i', metadata,types_o+i*104)
    classes.append(dict(idx=i,name=string_at(x[0]),namespace=string_at(x[1]),method_start=x[13],method_count=x[20]&0xffff))

methods=[]
for i in range(methods_len//56):
    x=struct.unpack_from('<14i',metadata,methods_o+i*56)
    methods.append((string_at(x[0]),x[1]))

focus_terms=('battle','boss','custard','laalaa','ending','enddemo','player','flashlight','health','enemy','surviv','monster')
focus=[]
with open(f'{OUT}/classes.csv','w',encoding='utf-8',newline='') as f:
    w=csv.writer(f)
    w.writerow(['type_index','namespace','class_name','method_count'])
    for cls in classes:
        w.writerow([cls['idx'],cls['namespace'],cls['name'],cls['method_count']])
        if not cls['namespace'].startswith(('UnityEngine','System','Mono','Microsoft')) and any(k in cls['name'].lower() for k in focus_terms):
            focus.append(cls)

with open(f'{OUT}/focus_methods.csv','w',encoding='utf-8',newline='') as f:
    w=csv.writer(f)
    w.writerow(['namespace','class_name','method_name'])
    for cls in focus:
        st=cls['method_start']
        for j in range(max(0,st),min(st+cls['method_count'],len(methods))):
            w.writerow([cls['namespace'],cls['name'],methods[j][0]])

with open(f'{OUT}/metadata_summary.txt','w',encoding='utf-8') as f:
    f.write('Apocalypse DLC - IL2CPP metadata 24\n')
    f.write(f'Type definitions: {len(classes)}\n')
    f.write(f'Method definitions: {len(methods)}\n')
    f.write(f'Focused classes: {len(focus)}\n')
    f.write('Method names come from metadata; C# source code was NOT recovered.\n')

if '--metadata-only' in sys.argv:
    print(f'Parsed {len(classes)} types, {len(methods)} methods. Metadata-only mode.')
    raise SystemExit(0)

# Inspect MonoBehaviour -> MonoScript -> GameObject links in the Unity scene bundle.
# UnityPy may be unable to parse stripped/missing typetrees. We record errors rather
# than claiming that an unresolvable link is absent from the original game.
import UnityPy
env=UnityPy.load('game.unity3d')
counts=collections.Counter()
script_refs=collections.Counter()
status=collections.Counter()
errors=[]
with open(f'{OUT}/scene_script_links.csv','w',encoding='utf-8',newline='') as f:
    w=csv.writer(f)
    w.writerow(['asset_file','game_object','namespace','script_class','assembly','link_status'])
    for obj in env.objects:
        counts[obj.type.name]+=1
        if obj.type.name!='MonoBehaviour':
            continue
        asset_file=str(getattr(getattr(obj,'assets_file',None),'name','?'))
        game_object=''
        namespace=''
        script_class=''
        assembly=''
        link_status='unresolved'
        try:
            try:
                d=obj.parse_monobehaviour_head()
            except (AttributeError, TypeError):
                d=obj.read(check_read=False)
            pp=getattr(d,'m_Script',None)
            if pp is None:
                link_status='no-script-pointer'
            else:
                script=pp.read() if hasattr(pp,'read') else pp.deref_parse_as_object()
                if script is None:
                    link_status='script-not-resolved'
                else:
                    script_class=str(getattr(script,'m_ClassName',''))
                    namespace=str(getattr(script,'m_Namespace',''))
                    assembly=str(getattr(script,'m_AssemblyName',''))
                    link_status='resolved' if script_class else 'script-name-empty'
                    if script_class:
                        script_refs[(namespace,script_class,assembly)]+=1
            try:
                go_ptr=getattr(d,'m_GameObject',None)
                if go_ptr:
                    go=go_ptr.read() if hasattr(go_ptr,'read') else go_ptr.deref_parse_as_object()
                    game_object=str(getattr(go,'m_Name',''))
            except Exception:
                pass
        except Exception as e:
            link_status='parse-failed'
            if len(errors)<40:
                errors.append(f'{asset_file}: {type(e).__name__}: {e}')
        status[link_status]+=1
        w.writerow([asset_file,game_object,namespace,script_class,assembly,link_status])

with open(f'{OUT}/script_usage.csv','w',encoding='utf-8',newline='') as f:
    w=csv.writer(f)
    w.writerow(['namespace','script_class','assembly','component_instances'])
    for (ns,cls,asm),n in script_refs.most_common():
        w.writerow([ns,cls,asm,n])

with open(f'{OUT}/scene_analysis.txt','w',encoding='utf-8') as f:
    f.write('Scene script-link inspection\n')
    f.write('NOTE: This does NOT make the APK an iOS Unity project.\n\n')
    for key in ('GameObject','MonoBehaviour','MonoScript','Mesh','Texture2D','Material','Terrain','TerrainData'):
        f.write(f'{key}: {counts[key]}\n')
    f.write('\nScript resolution:\n')
    for key,n in status.most_common():
        f.write(f'{key}: {n}\n')
    f.write('\nMost frequent resolved scripts:\n')
    for (ns,cls,asm),n in script_refs.most_common(40):
        f.write(f'{ns}.{cls} [{asm}]: {n}\n')
    if errors:
        f.write('\nSample parse errors:\n')
        f.write('\n'.join(errors))

print('Class definitions:',len(classes),'Methods:',len(methods))
print('MonoBehaviour script resolution:',dict(status))
print('Report saved in output/')
