Apocalypse DLC — ЭТАП 2: связи скриптов в сценах

1. Открой свой репозиторий GitHub (где уже есть APK в последнем опубликованном Release).
2. Создай новый файл: .github/workflows/apocalypse-stage2.yml
3. Скопируй содержимое apocalypse-stage2.yml в этот файл и сохрани (Commit changes).
4. В GitHub: Actions -> Apocalypse DLC - Script Links -> Run workflow.
5. Скачай Artifact Apocalypse-Stage2-Report и отправь ZIP в чат.

Этот запуск НЕ создаёт IPA. Он помогает выяснить, какие MonoBehaviour привязаны к каким игровым скриптам и объектам.
Внутри отчёта будут classes.csv, focus_methods.csv, scene_script_links.csv и scene_analysis.txt.

Используется тот же APK из Releases, без ПК-версии и без AssetRipper.
Если GitHub Actions завершится ошибкой, присылай скриншот красного шага.
